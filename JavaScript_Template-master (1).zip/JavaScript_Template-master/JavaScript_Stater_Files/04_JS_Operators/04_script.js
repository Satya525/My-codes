// Assignment operator =


// Arithmetic operators + - * /


// Short hand math += , -= , *= , /=


// Conditional operators < , > , <= , >= , !=


// Unary Operator ++ , -- (pre , post)


// Logical operators AND , OR


// String Concatenation Operator


// Ternary operator (? :)


// Type of operator


// == operator


// === operator