$(document).ready(() => {

    var getReqs = function () {
        $.ajax({
            type: "GET",
            url: 'https://api.mlab.com/api/1/databases/rssv1/collections/requirements_table?q={"postedBy":"Maneesha"}&apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi',
            success: function (result) {
                // console.log(result);

                var output =
                    "<table><thead><tr><th class='hidden'>ClientInterfaceId</th><th>ClientName</th><th class='hidden'>ClientManagerInterfaceId</th><th class='hidden'>ClientManagerEmailId</th><th>ClientManagerName</th><th>JobTitle</th><th class='hidden'>PrimarySkill</th><th class='hidden'>RequirementType</th><th class='hidden'>JobPostType</th><th class='hidden'>OfficeLocation</th><th>JobLocation</th><th>NoOfPosition</th><th>PriorityLevel</th><th>ExperienceForm</th><th>CTCRangeTo</th><th class='hidden'>JobBrief</th><th class='hidden'>JDDocumentBase64</th><th>CreatedByUserName</th><th>status</th><th>accepted</th><th>postedBy</th><th class='hidden'>createdOn</th><th class='hidden'>statusUpdatedOn</th><th class='hidden'>archive</th><th>source</th></tr></thead><tbody>";
                for (var i in result) {
                    var prior = "";
                    if (result[i].priority == 3)
                        prior = "High";
                    else if (result[i].priority == 2)
                        prior = "Normal";
                    else
                        prior = "Low";

                    if (result[i].status == 1)
                        result[i].status = "<span class='text-success'>Active</span>";
                    else
                        result[i].status = "<span class='text-warning'>Not Active</span>";

                    if (result[i].accepted == 1)
                        result[i].accepted = "<span class='text-success'>Accepted</span>";
                    else
                        result[i].accepted = "<span class='text-warning'>Not Accepted</span>";

                    result[i].CTCRangeTo = parseInt(result[i].CTCRangeTo).toLocaleString('en-IN', {
                        style: 'currency',
                        currency: 'INR',
                        minimumFractionDigits: 0,
                    });

                    output += "<tr><td class='hidden'>" + result[i].ClientInterfaceId + "</td><td>" + result[i].ClientName + "</td><td class='hidden'>" + result[i].ClientManagerInterfaceId + "</td><td class='hidden'>" + result[i].ClientManagerEmailId + "</td><td>" + result[i].ClientManagerName + "</td><td>" + result[i].JobTitle + "</td><td class='hidden'>" + result[i].PrimarySkill + "</td><td class='hidden'>" + result[i].RequirementType + "</td><td class='hidden'>" + result[i].JobPostType + "</td><td class='hidden'>" + result[i].OfficeLocation + "</td><td>" + result[i].JobLocation + "</td><td>" + result[i].NoOfPosition + "</td><td>" + result[i].PriorityLevel + "</td><td>" + result[i].ExperienceForm + "</td><td>" + result[i].CTCRangeTo + "</td><td class='hidden'>" + result[i].JobBrief + "</td><td class='hidden'>" + result[i].JDDocumentBase64 + "</td><td>" + result[i].CreatedByUserName + "</td><td>" + result[i].status + "</td><td>" + result[i].accepted + "</td><td>" + result[i].postedBy + "</td><td class='hidden'>" + result[i].createdOn + "</td><td class='hidden'>" + result[i].statusUpdatedOn + "</td><td class='hidden'>" + result[i].archive + "</td><td>" + result[i].source + "</td></tr>";
                }
                output += "</tbody></table>";

                $("#getdata").html(output);
                $("tbody").addClass("tbody");
                $("table").addClass(
                    "table table-responsive table-striped table-bordered table-hover table-condensed");
            }
        });
    }
    getReqs();

    var cli_IDURL =
        "https://api.mlab.com/api/1/databases/rssv1/collections/client_table?q{'client_name':TechM'}&apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi";

    $.getJSON(cli_IDURL, function (json) {
        // $('#client-TrID').empty();
        $('#client-TrID').val("");
        // $('#select-spoc').append($('<option>').text("Select SPOC"));
        $.each(json, function (i, obj) {
            // console.log("The Clienttable details:÷ " + obj);
            $('#client-TrID').val(obj.client_TrID);
        });
    });


    var getTCSURL =
        "https://api.mlab.com/api/1/databases/rssv1/collections/spoc_table?q={'client_name':'TechM'}&apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi";
    $.getJSON(getTCSURL, function (json) {
        $('#select-spoc').empty();
        $('#office-loc').val("");
        $('#select-spoc').append($('<option>').text("Select SPOC"));
        $.each(json, function (i, obj) {
            // console.log(obj);
            $('#select-spoc').append($('<option>').text(obj.spoc_name).attr(
                'value', obj.spoc_email));
        });
    });

    $('#select-spoc').change(function () {

        var spoc_email = $("#select-spoc").val();
        var myurl =
            "https://api.mlab.com/api/1/databases/rssv1/collections/spoc_table?q={spoc_email:'" +
            spoc_email + "'}&apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi"
        $.getJSON(myurl, function (json) {
            $('#office-loc').empty();
            $('#spoc-TrID').empty();
            $('#spoc-Name').empty();
            $.each(json, function (i, obj) {
                $('#office-loc').val(obj.spoc_loc);
                $('#spoc-TrID').val(obj.spoc_TrID);
                $('#spoc-Name').val(obj.spoc_name);
            });
        });
    });

    var JD_Doc = "";

    $('#jd-doc').change((e) => {
        // alert("file changed");
        var file = document.querySelector('input[type="file"]').files[0];
        if (file.size > 2097152) {
            alert("File is too big!");
            $('#jd-doc').val("");
        } else {
            var reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = function () {
                const content = JSON.stringify(reader.result);
                JD_Doc = content;
            };
            reader.onerror = function (error) {
                console.log('Error: ', error);
            };
        }

    });

    if ($('#add-req-techm').length > 0) {

        console.log($('#add-req-techm').length);

        document.getElementById('add-req-techm').addEventListener('submit', function (evt) {
            evt.preventDefault();

            if ($('#jd-doc').val() != "") {
                console.log("Mail or CRM executed.....");

            } else {
                console.log("MAIL CRM execution failed!");
                JD_Doc = "";
            }

            var data = JSON.stringify({
                ClientInterfaceId: $("#client-TrID").val(),
                ClientName: $("#select-client").val(),
                ClientManagerInterfaceId: $("#spoc-TrID").val(),
                ClientManagerEmailId: $("#select-spoc").val(),
                ClientManagerName: $("#spoc-Name").val(),
                JobTitle: $("#job-title").val(),
                PrimarySkill: $("#primary-skill").val(),
                RequirementType: $("#req-type").val(),
                JobPostType: $("#job-post-type").val(),
                OfficeLocation: $("#office-loc").val(),
                JobLocation: $("#job-loc").val(),
                NoOfPosition: $("#no-of-positions").val(),
                PriorityLevel: $("#job-priority").val(),
                ExperienceForm: $("#exp-from").val(),
                CTCRangeTo: $("#ctc-to").val(),
                JobBrief: ($("#job-brief").val() ? $("#job-brief").val() : null),
                JDDocumentBase64: JD_Doc,
                CreatedByUserName: $("#allot-to").val(),
                status: 0,
                accepted: 0,
                postedBy: $("#postedBy").val(),
                postedByRole: $("#postedByRole").val(),
                createdOn: new Date(),
                statusUpdatedOn: null,
                archive: 0,
                source: $("#source").val(),
            });
            $.ajax({
                type: "POST",
                contentType: "application/json",

                url: "https://api.mlab.com/api/1/databases/rssv1/collections/requirements_table?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi",
                data: data,
                // dataType:"json",
                success: function (respond) {
                    // console.log(respond);
                    // $(':input')
                    //     .not(
                    //         ':button, :submit, :reset, :hidden'
                    //     )
                    //     .val('')
                    //     .removeAttr('checked')
                    alert("your data successfully submit");
                    window.location = "./crm-techm-dashboard.html"
                    // getReqs();
                }

            });

        });

    }

});