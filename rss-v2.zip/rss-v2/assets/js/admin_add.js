$(document).ready(() => {

    $('#add-client').submit((e) => {
        e.preventDefault();
        var cleint_data = JSON.stringify({
            client_name: $("#client-name").val(),
            client_TrID: $('#clientTrID').val(),
            client_loc: $("#client-loc").val(),
        });
        console.log(cleint_data);
        $.ajax({
            type: "POST",
            contentType: "application/json",

            url: "https://api.mlab.com/api/1/databases/rssv1/collections/client_table?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi",
            data: cleint_data,
            // dataType:"json",
            success: function (respond) {
                console.log(respond);
                $(':input')
                    .not(
                        ':button, :submit, :reset, :hidden'
                    )
                    .val('')
                    .removeAttr('checked')
                alert("Client Addition Succeful!");
            }

        });
    });

    // Load Client List to the 'select-client' input on page load
    $.getJSON("https://api.mlab.com/api/1/databases/rssv1/collections/client_table?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi", function (json) {

        $('#select-client').empty();
        $('#select-client').append($('<option>').text("Select Client"));
        $.each(json, function (i, obj) {
            $('#select-client').append($('<option>').text(obj.client_name).attr('value', obj.val));
        });
    });

    $('#add-spoc').submit((e) => {
        e.preventDefault();
        var spoc_data = JSON.stringify({
            client_name: $("#select-client").val(),
            spoc_name: $('#spoc-name').val(),
            spoc_TrID: $("#spoc-TrID").val(),
            spoc_number: $("#spoc-number").val(),
            spoc_email: $("#spoc-email").val(),
            spoc_account: $("#spoc-account").val(),
            spoc_loc: $("#spoc-loc").val(),

        });
        console.log(spoc_data);
        $.ajax({
            type: "POST",
            contentType: "application/json",

            url: "https://api.mlab.com/api/1/databases/rssv1/collections/spoc_table?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi",
            data: spoc_data,
            // dataType:"json",
            success: function (respond) {
                console.log(respond);
                $(':input')
                    .not(
                        ':button, :submit, :reset, :hidden'
                    )
                    .val('')
                    .removeAttr('checked')
                alert("SPOC Addition Succeful!");
            }

        });
    });

});