$(document).ready(function() {
	$('#usercheck').hide();
    $('#idcheck').hide();
    $('#loccheck').hide();
    $('#spoccheck').hide();
    $('#spocTrID').hide();
    $('#spocnumber').hide();
    $('#spocloccheck').hide();
    
    

	var user_err = true;
	var pass_err = true;

	$('#client-name').keyup(function(){
		username_check();
	});
	function username_check(){
		var user_val = $('#client-name').val();
		
		if (user_val.length == '') {
			$('#usercheck').show();
			$('#usercheck').html(alert("** Please fill the Client Name & Client Name length must be between 3 to 15"));
			$('#usercheck').focus();
			$('#usercheck').css("color" , "red");
			user_err = false;
			return false();

		}else{
			$('#usercheck').hide();
		}
		if ((user_val.length < 0) || (user_val.length > 15)) {
			$('#usercheck').show();
			$('#usercheck').html(alert("** ClientName length must be between 3 to 15"));
			$('#usercheck').focus();
			$('#usercheck').css("color" , "red");
			user_err = false;
			return false();

		}else{
			$('#usercheck').hide();
		}
	}

	$('#clientTrID').keyup(function (){
		password_check();
	});

	 function password_check(){
	 	var passwordstd = $('#clientTrID').val();

	 	if(passwordstd.length == ''){
	 		$('#idcheck').show();
			$('#idcheck').html(alert("** Please fill the ID & ID length must be between 4 to 10"));
			$('#idcheck').focus();
			$('#idcheck').css("color" , "red");
			pass_err = false;
			return false;

		}else{
			$('#idcheck').hide();
	 }
	 if ((passwordstd.length < 0) || (passwordstd.length > 10)) {
			$('#idcheck').show();
			$('#idcheck').html(alert("** ID length must be between 4 to 10"));
			$('#idcheck').focus();
			$('#idcheck').css(("color" , "red"), ("background-color","gray"));
			pass_err = false;
			return false;

		}else{
			$('#idcheck').hide();
		}
         }
         
         $('#client-loc').keyup(function (){
            loc_check();
        });
    
         function loc_check(){
             var passwordst = $('#client-loc').val();
    
             if(passwordst.length == ''){
                 $('#loccheck').show();
                $('#loccheck').html(alert("** Please fill the Location & Location length must be between 4 to 10"));
                $('#loccheck').focus();
                $('#loccheck').css("color" , "red");
                loc_err = false;
                return false;
    
            }else{
                $('#loccheck').hide();
         }
         if ((passwordst.length < 0) || (passwordst.length > 10)) {
                $('#loccheck').show();
                $('#loccheck').html(alert("** Location must be between 4 to 10"));
                $('#loccheck').focus();
                $('#loccheck').css(("color" , "red"), ("background-color","gray"));
                loc_err = false;
                return false;
    
            }else{
                $('#loccheck').hide();
            }
             }

});


// For Spoc Add
//SPOC NAME

$('#spoc-name').keyup(function(){
    usernam_check();
});
function usernam_check(){
    var usr_val = $('#spoc-name').val();
    
    if (usr_val.length == '') {
        $('#spoccheck').show();
        $('#spoccheck').html(alert("** Please fill the Spoc Name & Spoc Name length must be between 3 to 15"));
        $('#spoccheck').focus();
        $('#spoccheck').css("color" , "red");
        user_err = false;
        return false();

    }else{
        $('#spoccheck').hide();
    }
    if ((usr_val.length < 0) || (usr_val.length > 15)) {
        $('#spoccheck').show();
        $('#spoccheck').html(alert("** SpocName length must be between 3 to 15"));
        $('#spoccheck').focus();
        $('#spoccheck').css("color" , "red");
        user_err = false;
        return false();

    }else{
        $('#spoccheck').hide();
    }
}

// spocTrID

/* $('#spoc-TrID').keyup(function(){
    username_check();
});
function username_check(){
    var user_val = $('#spoc-TrID').val();
    
    if (user_val.length == '') {
        $('#spocTrID').show();
        $('#spocTrID').html(alert("** Please fill the Spoc ID & Spoc ID length must be between 4 to 15"));
        $('#spocTrID').focus();
        $('#spocTrID').css("color" , "red");
        user_err = false;
        return false();

    }else{
        $('#spocTrID').hide();
    }
    if ((user_val.length < 0) || (user_val.length > 15)) {
        $('#spocTrID').show();
        $('#spocTrID').html(alert("** SpocID length must be between 4 to 15"));
        $('#spocTrID').focus();
        $('#spocTrID').css("color" , "red");
        user_err = false;
        return false();

    }else{
        $('#spocTrID').hide();
    }
} */

// Spoc Contact Number

$('#spoc-number').keyup(function(){
    username_check();
});
function username_check(){
    var user_val = $('#spoc-number').val();
    
    if (user_val.length == '') {
        $('#spocnumber').show();
        $('#spocnumber').html(alert("** Please fill the Spoc No & Spoc Number length must be 10"));
        $('#spocnumber').focus();
        $('#spocnumber').css("color" , "red");
        user_err = false;
        return false();

    }else{
        $('#spocnumber').hide();
    }
    if ((user_val.length < 0) || (user_val.length == 10)) {
        $('#spocnumber').show();
        $('#spocnumber').html(alert("** Spoc Number length must be 10"));
        $('#spocnumber').focus();
        $('#spocnumber').css("color" , "red");
        user_err = false;
        return false();

    }else{
        $('#spocnumber').hide();
    }
}
// Spoc Email Address

$('#spoc-email').keyup(function(){
    validateEmail();
});
function validateEmail(emailField){
    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

    if (reg.test(emailField.value) == false) 
    {
        alert('Invalid Email Address');
        return false;
    }

    return true;

}


// spoc location

$('#spoc-loc').keyup(function (){
    loc_check();
});

 function loc_check(){
     var passwordst = $('#spoc-loc').val();
 if ((passwordst.length < 0) || (passwordst.length > 50)) {
        $('#spocloccheck').show();
        $('#spocloccheck').html("** Location must be filled ");
        $('#spocloccheck').focus();
        $('#spocloccheck').css(("color" , "red"), ("background-color","gray"));
        loc_err = false;
        return false;

    }else{
        $('#spocloccheck').hide();
    }
     }