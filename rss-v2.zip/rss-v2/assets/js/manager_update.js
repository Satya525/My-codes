$('document').ready(() => {
    $.urlParam = function (name) {
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        return results[1] || 0;
    }
    var paramID = $.urlParam('id')
    console.log(paramID);

    $.ajax({
        type: "GET",
        url: 'https://api.mlab.com/api/1/databases/rssv1/collections/requirements_table/' + paramID + '?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi',
        success: function (result) {
            // $('#output').text(JSON.stringify(result));
            // console.log('got result');
            console.log(result);
            $('#client_name').text(result.ClientName);
            $('#spoc_name').text(result.ClientManagerName);
            $('#job_title').text(result.JobTitle);
            $('#posted_by').text(result.postedBy);
            $('#j_status').empty();
            $('#j_status').append($('<option>').text("Active").attr('value', 1));
            $('#j_status').append($('<option>').text("Not Active").attr('value', 0));

            $('#j_archive').empty();
            $('#j_archive').append($('<option>').text("Dont Archive").attr('value', 0));
            $('#j_archive').append($('<option>').text("Archive").attr('value', 1));
        }
    });

    document.getElementById('update-req').addEventListener('submit', function (evt) {
        evt.preventDefault();

        var data = JSON.stringify({
            "$set": {
                status: parseInt($('#j_status').val()),
                archive: parseInt($('#j_archive').val()),
            }
        });
        // console.log(data);
        $.ajax({
            type: "PUT",
            contentType: "application/json",
            url: "https://api.mlab.com/api/1/databases/rssv1/collections/requirements_table/" + paramID + "?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi",
            data: data,
            // dataType:"json",
            success: function (respond) {
                console.log(respond);
                // Page redirection after update
                window.location = "./manager-dashboard.html";
            },
            error: function (e) {
                alert("Error " + e);
            }

        });

    });


});