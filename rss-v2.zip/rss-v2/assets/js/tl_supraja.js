var acceptReq = function (id){

    var data = JSON.stringify({
        "$set": {
            accepted: 1,
        }
    });

    $.ajax({
        type: "PUT",
        contentType: "application/json",
        url: "https://api.mlab.com/api/1/databases/rssv1/collections/requirements_table/" + id + "?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi",
        data: data,
        success: function (respond) {
            console.log(respond);
            // Page redirection after update
            window.location = "./tl-dashboard.html";
        },
        error: function (e) {
            alert("Error " + e);
        }

    });
};
$(document).ready(() => {

    var getReqs = function () {

        $.ajax({
            type: "GET",
            url: 'https://api.mlab.com/api/1/databases/rssv1/collections/requirements_table?q={"CreatedByUserName":"supraja","status":1,"archive":0}&apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi',
            success: function (result) {
                var output =
                    "<table><thead><tr><th class='hidden'>ClientInterfaceId</th><th>ClientName</th><th class='hidden'>ClientManagerInterfaceId</th><th class='hidden'>ClientManagerEmailId</th><th>ClientManagerName</th><th>JobTitle</th><th class='hidden'>PrimarySkill</th><th class='hidden'>RequirementType</th><th class='hidden'>JobPostType</th><th class='hidden'>OfficeLocation</th><th>JobLocation</th><th>NoOfPosition</th><th>PriorityLevel</th><th>ExperienceForm</th><th>CTCRangeTo</th><th class='hidden'>JobBrief</th><th class='hidden'>JDDocumentBase64</th><th>CreatedByUserName</th><th>status</th><th>accepted</th><th>postedBy</th><th class='hidden'>createdOn</th><th class='hidden'>statusUpdatedOn</th><th class='hidden'>archive</th><th>source</th></tr></thead><tbody>";
                for (var i in result) {
                    var prior = "";
                    if (result[i].priority == 3)
                        prior = "High";
                    else if (result[i].priority == 2)
                        prior = "Normal";
                    else
                        prior = "Low";

                    if (result[i].status == 1)
                        result[i].status = "<span class='text-success'>Active</span>";
                    else
                        result[i].status = "<span class='text-warning'>Not Active</span>";

                    if (result[i].accepted == 1)
                        result[i].accepted = "<span class='text-success'>Accepted</span>";
                    else
                        result[i].accepted = "<button title='Click to Accept the requirement' onclick=acceptReq('"+ result[i]._id.$oid +"') class='btn btn-warning btn-sm'>Not Accepted</button>";

                    result[i].CTCRangeTo = parseInt(result[i].CTCRangeTo).toLocaleString('en-IN', {
                        style: 'currency',
                        currency: 'INR',
                        minimumFractionDigits: 0,
                    });

                    output += "<tr><td class='hidden'>" + result[i].ClientInterfaceId + "</td><td>" + result[i].ClientName + "</td><td class='hidden'>" + result[i].ClientManagerInterfaceId + "</td><td class='hidden'>" + result[i].ClientManagerEmailId + "</td><td>" + result[i].ClientManagerName + "</td><td>" + result[i].JobTitle + "</td><td class='hidden'>" + result[i].PrimarySkill + "</td><td class='hidden'>" + result[i].RequirementType + "</td><td class='hidden'>" + result[i].JobPostType + "</td><td class='hidden'>" + result[i].OfficeLocation + "</td><td>" + result[i].JobLocation + "</td><td>" + result[i].NoOfPosition + "</td><td>" + result[i].PriorityLevel + "</td><td>" + result[i].ExperienceForm + "</td><td>" + result[i].CTCRangeTo + "</td><td class='hidden'>" + result[i].JobBrief + "</td><td class='hidden'>" + result[i].JDDocumentBase64 + "</td><td>" + result[i].CreatedByUserName + "</td><td>" + result[i].status + "</td><td>" + result[i].accepted + "</td><td>" + result[i].postedBy + "</td><td class='hidden'>" + result[i].createdOn + "</td><td class='hidden'>" + result[i].statusUpdatedOn + "</td><td class='hidden'>" + result[i].archive + "</td><td>" + result[i].source + "</td></tr>";
                }
                output += "</tbody></table>";

                $("#getdata").html(output);
                $("tbody").addClass("tbody");
                $("table").addClass(
                    "table table-responsive table-striped table-bordered table-hover table-condensed");
            }
        });
    }
    getReqs();

    $('#export-btn').click(function () {
        $("table").tableExport({
            formats: ["xlsx", "csv"],
            bootstrap: true,
            ignoreCols: [4, 18, 19, 20, 21, 22, 23, 24],
        });
        $(this).hide();
    });

});