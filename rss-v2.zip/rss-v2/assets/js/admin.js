$(document).ready(() => {

    var getClients = function () {
        $.ajax({
            type: "GET",
            url: 'https://api.mlab.com/api/1/databases/rssv1/collections/client_table?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi',
            success: function (result) {
                // console.log(result);

                var output =
                    "<table><thead><tr><th>Client</th><th>Client ID</th><th>TR RefID</th></tr></thead><tbody>";
                for (var i in result) {
                    // var prior = "";
                    // if (result[i].priority == 3)
                    //     prior = "High";
                    // else if (result[i].priority == 2)
                    //     prior = "Normal";
                    // else
                    //     prior = "Low";
                    output += "<tr><td>" + result[i].client_name +
                        "</td><td>" + result[i]._id.$oid + "</td><td>" + result[i].client_TrID + "</td></tr>";
                }
                output += "</tbody></table>";

                $("#getClients").html(output);
                $("tbody").addClass("tbody");
                $("table").addClass(
                    "table table-responsive table-striped table-bordered table-hover");
            }
        });
    }
    getClients();

    var getSPOCs = function () {
        $.ajax({
            type: "GET",
            url: "https://api.mlab.com/api/1/databases/rssv1/collections/spoc_table?s={'client':1}&apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi",
            success: function (result) {
                // console.log(result);

                var output =
                    "<table><thead><tr><th>Client</th><th>SPOC</th><th>Number</th><th>E-Mail</th><th>Location</th><th>Account</th></tr></thead><tbody>";
                for (var i in result) {
                    output += "<tr><td>" + result[i].client_name +
                        "</td><td>" + result[i].spoc_name + "</td><td>" + result[i].spoc_number + "</td><td>" + result[i].spoc_email + "</td><td>" + result[i].spoc_loc + "</td><td>" + result[i].spoc_account + "</td></tr>";
                }
                output += "</tbody></table>";

                $("#getSPOCs").html(output);
                $("tbody").addClass("tbody");
                $("table").addClass(
                    "table table-responsive table-striped table-bordered table-hover");
            }
        });
    }
    getSPOCs();

});