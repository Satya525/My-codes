$(document).ready(() => {

    $.getJSON(
        "https://api.mlab.com/api/1/databases/rssv1/collections/client_table?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi",
        function (json) {
            $('#select-client').empty();
            $('#select-client').append($('<option>').text("Select Client"));
            $.each(json, function (i, obj) {
                $('#select-client').append($('<option>').text(obj.client_name).attr('value',
                    obj.val));
            });
            $('#client-TrID').val("");
        });

    $('#select-client').change(function () {



        var client_name = $("#select-client").val();

        var cli_IDURL =
            "https://api.mlab.com/api/1/databases/rssv1/collections/client_table?q{'client_name:" +
            client_name +
            "'}&apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi";

        var myurl =
            "https://api.mlab.com/api/1/databases/rssv1/collections/spoc_table?q={client_name:'" +
            client_name + "'}&apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi";
        $.getJSON(myurl, function (json) {
            $('#select-spoc').empty();
            $('#office-loc').val("");
            $('#select-spoc').append($('<option>').text("Select SPOC"));
            $.each(json, function (i, obj) {
                // console.log(obj);
                $('#select-spoc').append($('<option>').text(obj.spoc_name).attr(
                    'value', obj.spoc_email));
            });
        });
        $.getJSON(cli_IDURL, function (json) {
            // $('#client-TrID').empty();
            $('#client-TrID').val("");
            // $('#select-spoc').append($('<option>').text("Select SPOC"));
            $.each(json, function (i, obj) {
                // console.log("The Clienttable details:÷ " + obj);
                $('#client-TrID').val(obj.client_TrID);
            });
        });
    });

    $('#select-spoc').change(function () {

        var spoc_email = $("#select-spoc").val();
        var myurl =
            "https://api.mlab.com/api/1/databases/rssv1/collections/spoc_table?q={spoc_email:'" +
            spoc_email + "'}&apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi"
        $.getJSON(myurl, function (json) {
            $('#office-loc').empty();
            $('#spoc-TrID').empty();
            $('#spoc-Name').empty();
            $.each(json, function (i, obj) {
                $('#office-loc').val(obj.spoc_loc);
                $('#spoc-TrID').val(obj.spoc_TrID);
                $('#spoc-Name').val(obj.spoc_name);
            });
        });
    });

    var JD_Doc = "";

    $('#jd-doc').change((e) => {
        // alert("file changed");
        var file = document.querySelector('input[type="file"]').files[0];
        if (file.size > 2097152) {
            alert("File is too big!");
            $('#jd-doc').val("");
        } else {
            var reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = function () {
                const content = JSON.stringify(reader.result);
                JD_Doc = content;
            };
            reader.onerror = function (error) {
                console.log('Error: ', error);
            };
        }

    });

    document.getElementById('add-req').addEventListener('submit', function (evt) {
        evt.preventDefault();

        if ($('#source').val() == "Mail" || $('#source').val() == "CRM Portal") {
            console.log("Mail or CRM executed.....");

        } else {
            console.log("MAIL CRM execution failed!");
            JD_Doc = null;
        }

        var data = JSON.stringify({
            ClientInterfaceId: $("#client-TrID").val(),
            ClientName: $("#select-client").val(),
            ClientManagerInterfaceId: $("#spoc-TrID").val(),
            ClientManagerEmailId: $("#select-spoc").val(),
            ClientManagerName: $("#spoc-Name").val(),
            JobTitle: $("#job-title").val(),
            PrimarySkill: $("#primary-skill").val(),
            RequirementType: $("#req-type").val(),
            JobPostType: $("#job-post-type").val(),
            OfficeLocation: $("#office-loc").val(),
            JobLocation: $("#job-loc").val(),
            NoOfPosition: $("#no-of-positions").val(),
            PriorityLevel: $("#job-priority").val(),
            ExperienceForm: $("#exp-from").val(),
            CTCRangeTo: $("#ctc-to").val(),
            JobBrief: ($("#job-brief").val() ? $("#job-brief").val() : null),
            JDDocumentBase64: JD_Doc,
            CreatedByUserName: $("#allot-to").val(),
            status: 1,
            accepted: 0,
            postedBy: $("#postedBy").val(),
            postedByRole: $("#postedByRole").val(),
            createdOn: new Date(),
            statusUpdatedOn: null,
            archive: 0,
            source: $("#source").val(),
        });
        $.ajax({
            type: "POST",
            contentType: "application/json",

            url: "https://api.mlab.com/api/1/databases/rssv1/collections/requirements_table?apiKey=GK7Q1vbokviBKtN-W0abEJioaecJxwdi",
            data: data,
            // dataType:"json",
            success: function (respond) {
                // console.log(respond);
                // $(':input')
                //     .not(
                //         ':button, :submit, :reset, :hidden'
                //     )
                //     .val('')
                //     .removeAttr('checked')
                alert("your data successfully submit");
                window.location = "./crm-techm-dashboard.html";
                // getReqs();
            }

        });

    });

});