/*
Please consider that the JS part isn't production ready at all, I just code it to show the concept of merging filters and titles together !
*/
$(document).ready(function(){
    $('.filterable .btn-filter').click(function(){
        var $panel = $(this).parents('.filterable'),
        $filters = $panel.find('.filters input'),
        $tbody = $panel.find('.table tbody');
        if ($filters.prop('disabled') == true) {
            $filters.prop('disabled', false);
            $filters.first().focus();
        } else {
            $filters.val('').prop('disabled', true);
            $tbody.find('.no-result').remove();
            $tbody.find('tr').show();
        }
    });

    $('.filterable .filters input').keyup(function(e){
        /* Ignore tab key */
        var code = e.keyCode || e.which;
        if (code == '9') return;
        /* Useful DOM data and selectors */
        var $input = $(this),
        inputContent = $input.val().toLowerCase(),
        $panel = $input.parents('.filterable'),
        column = $panel.find('.filters th').index($input.parents('th')),
        $table = $panel.find('.table'),
        $rows = $table.find('tbody tr');
        /* Dirtiest filter function ever ;) */
        var $filteredRows = $rows.filter(function(){
            var value = $(this).find('td').eq(column).text().toLowerCase();
            return value.indexOf(inputContent) === -1;
        });
        /* Clean previous no-result if exist */
        $table.find('tbody .no-result').remove();
        /* Show all rows, hide filtered ones (never do that outside of a demo ! xD) */
        $rows.show();
        $filteredRows.hide();
        /* Prepend no-result row if all rows are filtered */
        if ($filteredRows.length === $rows.length) {
            $table.find('tbody').prepend($('<tr class="no-result text-center"><td colspan="'+ $table.find('.filters th').length +'">No result found</td></tr>'));
        }
    });
});

/* $(document).ready(function(){
    $("#show").mouseenter(function(){
        $("#hid").show(500);
    });
    $("#show").mouseleave(function(){
        $("#hid").hide(500);
    });
 */
    // $("#show").mouseenter(function(){
    //     $('.myModal').show(200);
    // });
    
    // $(".slide-down").click(function(){
    //     $(".box").slideDown();
    // });
// });
/* $(document).ready(function(){
    $("#show1").mouseenter(function(){
        $("#hid1").slideToggle(500);
    });
    $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    });
}); */
$(document).ready(function(){
    $(".show1").click(function(){
        $("#hid1").toggle(200);
        $("#hid11").toggle(200);
        $("#hid12").toggle(200);
        $("#hid13").toggle(200);
        $("#hid14").toggle(200);
        // $(".sar").html("<marquee> Hello World</marquee>");
        // $("marquee").css("
        // "direction" :"right"
        // ");
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});
/* $(document).ready(function(){
    $("#show3").mouseenter(function(){
        $("#hid3").show(500);
    });
    $("#show3").mouseleave(function(){
        $("#hid3").hide(200);
    });
}); */
$(document).ready(function(){
    $(".show2").click(function(){
        $("#hid2").toggle(200);
        $("#hid21").toggle(200);
        $("#hid22").toggle(200);
        $("#hid23").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show3").click(function(){
        $("#hid3").toggle(200);
        $("#hid31").toggle(200);
        $("#hid32").toggle(200);
        $("#hid33").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show4").click(function(){
        $("#hid4").toggle(200);
        $("#hid41").toggle(200);
        // $("#hid32").toggle(200);
        // $("#hid33").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show5").click(function(){
        $("#hid5").toggle(200);
        $("#hid51").toggle(200);
        $("#hid52").toggle(200);
        $("#hid53").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show6").click(function(){
        $("#hid6").toggle(200);
        $("#hid61").toggle(200);
        $("#hid62").toggle(200);
        $("#hid63").toggle(200);
        $("#hid64").toggle(200);
        $("#hid65").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show7").click(function(){
        $("#hid7").toggle(200);
        $("#hid71").toggle(200);
        $("#hid72").toggle(200);
        $("#hid73").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show8").click(function(){
        $("#hid8").toggle(200);
        $("#hid81").toggle(200);
        $("#hid82").toggle(200);
        $("#hid83").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show9").click(function(){
        $("#hid9").toggle(200);
        $("#hid91").toggle(200);
        $("#hid92").toggle(200);
        $("#hid93").toggle(200);
        $("#hid94").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show10").click(function(){
        $("#hid10").toggle(200);
        $("#hid101").toggle(200);
        $("#hid102").toggle(200);
        $("#hid103").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show11").click(function(){
        $("#hid11").toggle(200);
        $("#hid111").toggle(200);
        $("#hid112").toggle(200);
        $("#hid113").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show12").click(function(){
        $("#hid12").toggle(200);
        $("#hid121").toggle(200);
        $("#hid122").toggle(200);
        $("#hid123").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show13").click(function(){
        $("#hid13").toggle(200);
        $("#hid131").toggle(200);
        $("#hid132").toggle(200);
        $("#hid133").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show14").click(function(){
        $("#hid14").toggle(200);
        $("#hid141").toggle(200);
        $("#hid142").toggle(200);
        $("#hid143").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show15").click(function(){
        $("#hid15").toggle(200);
        $("#hid151").toggle(200);
        $("#hid152").toggle(200);
        $("#hid153").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show16").click(function(){
        $("#hid16").toggle(200);
        $("#hid161").toggle(200);
        $("#hid162").toggle(200);
        $("#hid163").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});

$(document).ready(function(){
    $(".show17").click(function(){
        $("#hid17").toggle(200);
        $("#hid171").toggle(200);
        $("#hid172").toggle(200);
        $("#hid173").toggle(200);
    });
    /* $("#show1").mouseleave(function(){
        $("#hid1").hide(200);
    }); */
});